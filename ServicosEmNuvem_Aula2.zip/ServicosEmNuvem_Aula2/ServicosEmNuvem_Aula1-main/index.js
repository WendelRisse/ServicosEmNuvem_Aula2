
// function chamarServicoviaCNPJ() {
//     cnpj_digitado = document.getElementById("numero_cnpj").value;

//     fetch('https://receitaws.com.br/v1/cnpj/{cnpj}', { mode: 'no-cors'})
//   .then(blob => blob.json())
//   .then(data => {
//     console.table(data);
//     return data;
//   })
//   .catch(e => {
//     console.log(e);
//     return e;
//   });

//     if ( cnpj_digitado==""){
//         alert("Cadê o CNPJ?????");
//     }

//     alert('Você clicou no botão pesquisar e o metódo foi invocado!');

//     alert('O número do CNPJ digitado foi:' + cnpj_digitado.value);

//    // cnpj_digitado = "01001000";

//     const urlViaCNPJ = "https://receitaws.com.br/v1/cnpj/" + cnpj_digitado + "/json/";

//     fetch(urlViaCNPJ).then((response) => {
//         if (response.ok) {
//             alert("Resposta OK");

//             return response.json();
//         }

//         if (!response.ok) {
//             alert("Resposta Não OK");
//         }

//     }).then((data) => {
//         //alert(data);
//         console.log(data);
//     }).catch(error => {
//         alert("ALERT: Erro ao requisitar o serviço na nuvem!");

//         console.error("Erro ao requisitar o serviço na nuvem!");
//     })
// }
// Declara a variável fora da função
let cnpj_digitado;


function chamarServicoviaCNPJ() {
    // Obtém o CNPJ digitado pelo usuário
    const cnpj_digitado = document.getElementById("numero_cnpj").value;

    // Valida o CNPJ
    if (cnpj_digitado === "") {
        alert("Cadê o CNPJ?????");
        return;
    }

     // Monta a URL do proxy
  const urlProxy = `https://cors-anywhere.herokuapp.com/https://receitaws.com.br/v1/cnpj/${cnpj_digitado}`;

  // Realiza a requisição à API através do proxy
  fetch(urlProxy)
    .then((response) => {
      if (response.ok) {
        return response.json();
      } else {
        throw new Error(`Erro na requisição: ${response.status}`);
      }
    })
    .then((data) => {
      // Exibe os dados da empresa
      console.log(data);
    })
    .catch((error) => {
      // Exibe a mensagem de erro
      alert(`Erro: ${error.message}`);
    });

//     // Função para escrever os dados da empresa no HTML
// function escreverDadosEmpresa(data) {
//     // Seleciona o elemento onde os dados serão escritos
//     const resultadoDiv = document.getElementById("resultado");

//     // Escreve os dados da empresa no elemento selecionado
//     resultadoDiv.innerHTML = `
//         <h2>Dados da Empresa:</h2>
//         <p><strong>Razão Social:</strong> ${data.nome}</p>
//         <p><strong>Nome Fantasia:</strong> ${data.fantasia}</p>
//         <p><strong>Endereço:</strong> ${data.logradouro}, ${data.numero} - ${data.bairro}</p>
//         <p><strong>Cidade:</strong> ${data.municipio} - ${data.uf}</p>
//     `;
// }
  
    // // Monta a URL da API
    // const urlViaCNPJ = `https://receitaws.com.br/v1/cnpj/${cnpj_digitado}`;

    // // Realiza a requisição à API
    // fetch(urlViaCNPJ)
    //     .then((response) => {
    //         if (response.ok) {
    //             // A requisição foi bem sucedida
    //             return response.json();
    //         } else {
    //             // A requisição falhou
    //             throw new Error(`Erro na requisição: ${response.status}`);
    //         }
    //     })
    //     .then((data) => {
    //         // Exibe os dados da empresa
    //         console.log(data);
    //     })
    //     .catch((error) => {
    //         // Exibe a mensagem de erro
    //         alert(`Erro: ${error.message}`);
    //     });
}
